import { Route } from "react-router-dom"

function ProtectedRoute({isAuth: isAuth}){

    <Route/>
}
export default ProtectedRoute